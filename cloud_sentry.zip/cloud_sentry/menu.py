from aws_operations import (
    describe_instances,
    create_s3_bucket,
    terminate_instance,
    delete_s3_bucket,
    launch_instance,
    start_instance,
    stop_instance,
    create_security_group,
    delete_security_group,
    modify_security_group,
    upload_file,
    download_file,
    create_snapshot,
    restore_snapshot,
    tag_instance,
    tag_bucket
)
from validation import validate_instance_id, validate_bucket_name
import logging

# Interactive menu
def main_menu():
    print("Welcome to the Cloud Sentry!")
    options = [
        "Describe EC2 Instances",
        "Create an S3 Bucket",
        "Terminate an EC2 Instance",
        "Delete an S3 Bucket",
        "Launch an EC2 Instance",
        "Start an EC2 Instance",
        "Stop an EC2 Instance",
        "Create a Security Group",
        "Delete a Security Group",
        "Modify a Security Group",
        "Upload a File to S3 Bucket",
        "Download a File from S3 Bucket",
        "Create an EBS Snapshot",
        "Restore an EBS Snapshot",
        "Tag an EC2 Instance",
        "Tag an S3 Bucket",
        "Exit"
    ]

    while True:
        for index, option in enumerate(options):
            print(f"{index+1}. {option}")

        choice = input("Enter your choice: ")

        if choice.isdigit() and 1 <= int(choice) <= len(options):
            selected_option = options[int(choice)-1]
            if selected_option == "Describe EC2 Instances":
                describe_instances()
            elif selected_option == "Create an S3 Bucket":
                bucket_name = input("Enter the bucket name: ")
                try:
                    bucket_name = validate_bucket_name(bucket_name)
                    create_s3_bucket(bucket_name)
                except ValueError as e:
                    logging.error(f"Error in create_s3_bucket: {e}")
                    print(f"Invalid bucket name: {e}")
            elif selected_option == "Terminate an EC2 Instance":
                terminate_instance()
            elif selected_option == "Delete an S3 Bucket":
                delete_s3_bucket()
            elif selected_option == "Launch an EC2 Instance":
                launch_instance()
            elif selected_option == "Start an EC2 Instance":
                start_instance()
            elif selected_option == "Stop an EC2 Instance":
                stop_instance()
            elif selected_option == "Create a Security Group":
                create_security_group()
            elif selected_option == "Delete a Security Group":
                delete_security_group()
            elif selected_option == "Modify a Security Group":
                modify_security_group()
            elif selected_option == "Upload a File to S3 Bucket":
                upload_file()
            elif selected_option == "Download a File from S3 Bucket":
                download_file()
            elif selected_option == "Create an EBS Snapshot":
                create_snapshot()
            elif selected_option == "Restore an EBS Snapshot":
                restore_snapshot()
            elif selected_option == "Tag an EC2 Instance":
                tag_instance()
            elif selected_option == "Tag an S3 Bucket":
                tag_bucket()
            elif selected_option == "Exit":
                print("Goodbye!")
                return
        else:
            print("Invalid choice. Please try again.")
