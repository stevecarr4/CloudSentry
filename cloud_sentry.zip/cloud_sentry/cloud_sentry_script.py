from menu import main_menu

# Start the script
if __name__ == "__main__":
    main_menu()
